
`timescale 1 ns / 1 ps

	module adc_psctl_v1_0 #
	(
		// Users to add parameters here

		// User parameters ends
		// Do not modify the parameters beyond this line


		// Parameters of Axi Master Bus Interface M00_AXI
		//parameter  C_M00_AXI_TARGET_SLAVE_BASE_ADDR	= 32'h40000000,
		parameter integer C_M00_AXI_BURST_LEN	= 4,
		parameter integer C_M00_AXI_ID_WIDTH	= 1,
		parameter integer C_M00_AXI_ADDR_WIDTH	= 32,
		parameter integer C_M00_AXI_DATA_WIDTH	= 32,
		parameter integer C_M00_AXI_AWUSER_WIDTH	= 0,
		parameter integer C_M00_AXI_ARUSER_WIDTH	= 0,
		parameter integer C_M00_AXI_WUSER_WIDTH	= 0,
		parameter integer C_M00_AXI_RUSER_WIDTH	= 0,
		parameter integer C_M00_AXI_BUSER_WIDTH	= 0,

		// Parameters of Axi Slave Bus Interface S00_AXI
		parameter integer C_S00_AXI_DATA_WIDTH	= 32,
		parameter integer C_S00_AXI_ADDR_WIDTH	= 4
	)
	(
		// Users to add ports here
		output wire adc_clk_spi,
		output wire adc_cs_spi,
		input wire adc_sd_spi_1,
		input wire adc_sd_spi_2,
		input wire adc_sd_spi_3,
		input wire adc_sd_spi_4,
		input wire adc_sd_spi_5,
		input wire adc_sd_spi_6,
		input wire adc_sd_spi_7,
		input wire adc_sd_spi_8,
		input wire adc_sd_spi_9,
		input wire adc_sd_spi_10,
		input wire adc_sd_spi_11,
		input wire adc_sd_spi_12,
		input wire adc_sd_spi_13,
		input wire adc_sd_spi_14,
		input wire adc_sd_spi_15,
		input wire adc_sd_spi_16,
				
        output wire adc_done,
        
        output wire adc_done_int,
        output wire adc_done_int_scaled,
        
        input wire adc_start,
		// User ports ends
		// Do not modify the ports beyond this line


		// Ports of Axi Master Bus Interface M00_AXI
		input wire  m00_axi_init_axi_txn,
		output wire  m00_axi_txn_done,
		output wire  m00_axi_error,
		input wire  m00_axi_aclk,
		input wire  m00_axi_aresetn,
		output wire [C_M00_AXI_ID_WIDTH-1 : 0] m00_axi_awid,
		output wire [C_M00_AXI_ADDR_WIDTH-1 : 0] m00_axi_awaddr,
		output wire [7 : 0] m00_axi_awlen,
		output wire [2 : 0] m00_axi_awsize,
		output wire [1 : 0] m00_axi_awburst,
		output wire  m00_axi_awlock,
		output wire [3 : 0] m00_axi_awcache,
		output wire [2 : 0] m00_axi_awprot,
		output wire [3 : 0] m00_axi_awqos,
		output wire [C_M00_AXI_AWUSER_WIDTH-1 : 0] m00_axi_awuser,
		output wire  m00_axi_awvalid,
		input wire  m00_axi_awready,
		output wire [C_M00_AXI_DATA_WIDTH-1 : 0] m00_axi_wdata,
		output wire [C_M00_AXI_DATA_WIDTH/8-1 : 0] m00_axi_wstrb,
		output wire  m00_axi_wlast,
		output wire [C_M00_AXI_WUSER_WIDTH-1 : 0] m00_axi_wuser,
		output wire  m00_axi_wvalid,
		input wire  m00_axi_wready,
		input wire [C_M00_AXI_ID_WIDTH-1 : 0] m00_axi_bid,
		input wire [1 : 0] m00_axi_bresp,
		input wire [C_M00_AXI_BUSER_WIDTH-1 : 0] m00_axi_buser,
		input wire  m00_axi_bvalid,
		output wire  m00_axi_bready,
		output wire [C_M00_AXI_ID_WIDTH-1 : 0] m00_axi_arid,
		output wire [C_M00_AXI_ADDR_WIDTH-1 : 0] m00_axi_araddr,
		output wire [7 : 0] m00_axi_arlen,
		output wire [2 : 0] m00_axi_arsize,
		output wire [1 : 0] m00_axi_arburst,
		output wire  m00_axi_arlock,
		output wire [3 : 0] m00_axi_arcache,
		output wire [2 : 0] m00_axi_arprot,
		output wire [3 : 0] m00_axi_arqos,
		output wire [C_M00_AXI_ARUSER_WIDTH-1 : 0] m00_axi_aruser,
		output wire  m00_axi_arvalid,
		input wire  m00_axi_arready,
		input wire [C_M00_AXI_ID_WIDTH-1 : 0] m00_axi_rid,
		input wire [C_M00_AXI_DATA_WIDTH-1 : 0] m00_axi_rdata,
		input wire [1 : 0] m00_axi_rresp,
		input wire  m00_axi_rlast,
		input wire [C_M00_AXI_RUSER_WIDTH-1 : 0] m00_axi_ruser,
		input wire  m00_axi_rvalid,
		output wire  m00_axi_rready,

		// Ports of Axi Slave Bus Interface S00_AXI
		input wire  s00_axi_aclk,
		input wire  s00_axi_aresetn,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_awaddr,
		input wire [2 : 0] s00_axi_awprot,
		input wire  s00_axi_awvalid,
		output wire  s00_axi_awready,
		input wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_wdata,
		input wire [(C_S00_AXI_DATA_WIDTH/8)-1 : 0] s00_axi_wstrb,
		input wire  s00_axi_wvalid,
		output wire  s00_axi_wready,
		output wire [1 : 0] s00_axi_bresp,
		output wire  s00_axi_bvalid,
		input wire  s00_axi_bready,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_araddr,
		input wire [2 : 0] s00_axi_arprot,
		input wire  s00_axi_arvalid,
		output wire  s00_axi_arready,
		output wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_rdata,
		output wire [1 : 0] s00_axi_rresp,
		output wire  s00_axi_rvalid,
		input wire  s00_axi_rready
	);
	

	wire adc_start_trigger;
    wire adc_enable;
    wire adc_manual_trigger;
    wire adc_int_en;
	wire [31:0] adc_spi_clk_div;
	wire [31:0] adc_write_buffer;
	wire adc_scaled_int_en;
	wire [3:0] adc_scaled_int_factor;
	wire [255:0] adc_data;
			
// Instantiation of Axi Bus Interface M00_AXI
	adc_psctl_v1_0_M00_AXI # ( 
		//.C_M_TARGET_SLAVE_BASE_ADDR(C_M00_AXI_TARGET_SLAVE_BASE_ADDR),
		.C_M_AXI_BURST_LEN(C_M00_AXI_BURST_LEN),
		.C_M_AXI_ID_WIDTH(C_M00_AXI_ID_WIDTH),
		.C_M_AXI_ADDR_WIDTH(C_M00_AXI_ADDR_WIDTH),
		.C_M_AXI_DATA_WIDTH(C_M00_AXI_DATA_WIDTH),
		.C_M_AXI_AWUSER_WIDTH(C_M00_AXI_AWUSER_WIDTH),
		.C_M_AXI_ARUSER_WIDTH(C_M00_AXI_ARUSER_WIDTH),
		.C_M_AXI_WUSER_WIDTH(C_M00_AXI_WUSER_WIDTH),
		.C_M_AXI_RUSER_WIDTH(C_M00_AXI_RUSER_WIDTH),
		.C_M_AXI_BUSER_WIDTH(C_M00_AXI_BUSER_WIDTH)
	) adc_psctl_v1_0_M00_AXI_inst (
		.INIT_AXI_TXN(m00_axi_init_axi_txn),
		.TXN_DONE(m00_axi_txn_done),
		.ERROR(m00_axi_error),
		.M_AXI_ACLK(m00_axi_aclk),
		.M_AXI_ARESETN(m00_axi_aresetn),
		.M_AXI_AWID(m00_axi_awid),
		.M_AXI_AWADDR(m00_axi_awaddr),
		.M_AXI_AWLEN(m00_axi_awlen),
		.M_AXI_AWSIZE(m00_axi_awsize),
		.M_AXI_AWBURST(m00_axi_awburst),
		.M_AXI_AWLOCK(m00_axi_awlock),
		.M_AXI_AWCACHE(m00_axi_awcache),
		.M_AXI_AWPROT(m00_axi_awprot),
		.M_AXI_AWQOS(m00_axi_awqos),
		.M_AXI_AWUSER(m00_axi_awuser),
		.M_AXI_AWVALID(m00_axi_awvalid),
		.M_AXI_AWREADY(m00_axi_awready),
		.M_AXI_WDATA(m00_axi_wdata),
		.M_AXI_WSTRB(m00_axi_wstrb),
		.M_AXI_WLAST(m00_axi_wlast),
		.M_AXI_WUSER(m00_axi_wuser),
		.M_AXI_WVALID(m00_axi_wvalid),
		.M_AXI_WREADY(m00_axi_wready),
		.M_AXI_BID(m00_axi_bid),
		.M_AXI_BRESP(m00_axi_bresp),
		.M_AXI_BUSER(m00_axi_buser),
		.M_AXI_BVALID(m00_axi_bvalid),
		.M_AXI_BREADY(m00_axi_bready),
		.M_AXI_ARID(m00_axi_arid),
		.M_AXI_ARADDR(m00_axi_araddr),
		.M_AXI_ARLEN(m00_axi_arlen),
		.M_AXI_ARSIZE(m00_axi_arsize),
		.M_AXI_ARBURST(m00_axi_arburst),
		.M_AXI_ARLOCK(m00_axi_arlock),
		.M_AXI_ARCACHE(m00_axi_arcache),
		.M_AXI_ARPROT(m00_axi_arprot),
		.M_AXI_ARQOS(m00_axi_arqos),
		.M_AXI_ARUSER(m00_axi_aruser),
		.M_AXI_ARVALID(m00_axi_arvalid),
		.M_AXI_ARREADY(m00_axi_arready),
		.M_AXI_RID(m00_axi_rid),
		.M_AXI_RDATA(m00_axi_rdata),
		.M_AXI_RRESP(m00_axi_rresp),
		.M_AXI_RLAST(m00_axi_rlast),
		.M_AXI_RUSER(m00_axi_ruser),
		.M_AXI_RVALID(m00_axi_rvalid),
		.M_AXI_RREADY(m00_axi_rready),
		.C_M_TARGET_SLAVE_BASE_ADDR(adc_write_buffer), //Connects the PS-config'd buffer to the base address of the M_AXI interface
		.M_AXI_TX_DATA(adc_data)
	);

// Instantiation of Axi Bus Interface S00_AXI
	adc_psctl_v1_0_S00_AXI # ( 
		.C_S_AXI_DATA_WIDTH(C_S00_AXI_DATA_WIDTH),
		.C_S_AXI_ADDR_WIDTH(C_S00_AXI_ADDR_WIDTH)
	) adc_psctl_v1_0_S00_AXI_inst (
		.S_AXI_ACLK(s00_axi_aclk),
		.S_AXI_ARESETN(s00_axi_aresetn),
		.S_AXI_AWADDR(s00_axi_awaddr),
		.S_AXI_AWPROT(s00_axi_awprot),
		.S_AXI_AWVALID(s00_axi_awvalid),
		.S_AXI_AWREADY(s00_axi_awready),
		.S_AXI_WDATA(s00_axi_wdata),
		.S_AXI_WSTRB(s00_axi_wstrb),
		.S_AXI_WVALID(s00_axi_wvalid),
		.S_AXI_WREADY(s00_axi_wready),
		.S_AXI_BRESP(s00_axi_bresp),
		.S_AXI_BVALID(s00_axi_bvalid),
		.S_AXI_BREADY(s00_axi_bready),
		.S_AXI_ARADDR(s00_axi_araddr),
		.S_AXI_ARPROT(s00_axi_arprot),
		.S_AXI_ARVALID(s00_axi_arvalid),
		.S_AXI_ARREADY(s00_axi_arready),
		.S_AXI_RDATA(s00_axi_rdata),
		.S_AXI_RRESP(s00_axi_rresp),
		.S_AXI_RVALID(s00_axi_rvalid),
		.S_AXI_RREADY(s00_axi_rready),
		.S_AXI_ADC_EN(adc_enable),
		.S_AXI_ADC_MAN_TRIG(adc_manual_trigger),
		.S_AXI_ADC_INT_EN(adc_int_en),
		.S_AXI_ADC_SPI_CLK_DIV(adc_spi_clk_div),
		.S_AXI_ADC_WRITE_BUFFER(adc_write_buffer),
		.S_AXI_ADC_SCALED_INT_EN(adc_scaled_int_en),
		.S_AXI_ADC_SCALED_INT_FACTOR(adc_scaled_int_factor)
	);

	// Add user logic here
	assign adc_start_trigger = (adc_manual_trigger | adc_start) & adc_enable;
	assign adc_done_int = m00_axi_txn_done | ~adc_int_en;
	
	adc adc_1(
	   .clk(s00_axi_aclk),
	   .clk_div(adc_spi_clk_div),
	   .start(adc_start_trigger),
	   .clk_spi(adc_clk_spi),
	   .cs_spi(adc_cs_spi),
	   .sd_spi_1(adc_sd_spi_1),
	   .sd_spi_2(adc_sd_spi_2),
	   .sd_spi_3(adc_sd_spi_3),
	   .sd_spi_4(adc_sd_spi_4),
	   .sd_spi_5(adc_sd_spi_5),
	   .sd_spi_6(adc_sd_spi_6),
	   .sd_spi_7(adc_sd_spi_7),
	   .sd_spi_8(adc_sd_spi_8),
	   .sd_spi_9(adc_sd_spi_9),
	   .sd_spi_10(adc_sd_spi_10),
	   .sd_spi_11(adc_sd_spi_11),
	   .sd_spi_12(adc_sd_spi_12),
	   .sd_spi_13(adc_sd_spi_13),
	   .sd_spi_14(adc_sd_spi_14),
	   .sd_spi_15(adc_sd_spi_15),
	   .sd_spi_16(adc_sd_spi_16),
	   .done(adc_done),
	   .data(adc_data)
	);
	
	reg [31:0] scaled_int_counter = 32'b0;
    reg adc_scaled_int = 0;

	always @ (posedge m00_axi_txn_done) begin
	   if( adc_scaled_int_en == 0 ) begin
	       scaled_int_counter = 32'b0;
	       adc_scaled_int = 0;
	   end
	   
	   else begin
           if( scaled_int_counter == adc_scaled_int_factor) begin
               scaled_int_counter <= 0;
               adc_scaled_int <= 1;
           end
           else begin
               scaled_int_counter <= scaled_int_counter + 1;
               adc_scaled_int <= 0;
           end
	   end
	end
//	always @ (posedge s00_axi_aclk) begin
//	   if( adc_scaled_int_en == 0 ) begin
//	       scaled_int_counter = 32'b0;
//	       adc_scaled_int = 0;
//	   end
	   
//	   else begin
//	       if( m00_axi_txn_done == 1 ) begin
//               if( scaled_int_counter == adc_scaled_int_factor) begin
//                   scaled_int_counter <= 0;
//                   adc_scaled_int <= 1;
//               end
//               else begin
//                   scaled_int_counter <= scaled_int_counter + 1;
//                   adc_scaled_int <= 0;
//               end
//           end
           
//           else begin
//               scaled_int_counter <= scaled_int_counter;
//               adc_scaled_int <= adc_scaled_int;
//           end
//	   end
	   
//	end
	
	assign adc_done_int_scaled = adc_scaled_int | ~adc_scaled_int_en;
	
	endmodule
